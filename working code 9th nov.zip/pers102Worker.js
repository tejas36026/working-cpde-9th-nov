self.onmessage = function(e) {
  const { imageData, partNames, measurements } = e.data;
  console.log('e.data :>> ', e.data);

  // Create variations array to store all processed images
  const variations = [];

  // Process each part's image data
  imageData.forEach((imgData, index) => {
      const partName = partNames[index];
      const width = imgData.width;
      const height = imgData.height;

      // Create typed array from bufferctx
      const sourceData = new Uint8ClampedArray(imgData.data);

      // Only process left upper arm and left lower arm parts with rotations
      if (partName === 'left_upper_arm_front' || partName === 'left_upper_arm_back' ||
          partName === 'left_lower_arm_front' || partName === 'left_lower_arm_back') {

          // Get the center point for rotation based on average top point
          const rotationCenter = measurements[partName.replace('_front', '').replace('_back', '')].average.top;

          // Create 10 rotated variations from -45 to +45 degrees
          for (let rotation = -45; rotation <= 45; rotation += 10) {
              const rotatedData = rotateSegment(
                  sourceData,
                  width,
                  height,
                  rotationCenter,
                  rotation
              );

              // Calculate rotated keypoints
              const originalKeypoints = {
                  top: measurements[partName.replace('_front', '').replace('_back', '')].original[partName.includes('front') ? 'front' : 'back'].top,
                  bottom: measurements[partName.replace('_front', '').replace('_back', '')].original[partName.includes('front') ? 'front' : 'back'].bottom
              };

              const rotatedKeypoints = rotateKeypoints(
                  originalKeypoints,
                  rotationCenter,
                  rotation
              );

              variations.push({
                  partName: partName,
                  rotation: rotation,
                  width: width,
                  height: height,
                  data: rotatedData.buffer,
                  extremePoints: rotatedKeypoints,
                  originalKeypoints: originalKeypoints,
                  rotationCenter: rotationCenter
              });
          }
      } else {
          // For non-rotating parts, just pass through original data
          variations.push({
              partName: partName,
              rotation: 0,
              width: width,
              height: height,
              data: sourceData.buffer,
              extremePoints: null,
              originalKeypoints: null,
              rotationCenter: null
          });
      }
  });

  // Calculate average keypoints for each rotation
  const rotationAverages = {};
  for (let rotation = -45; rotation <= 45; rotation += 10) {
      const rotatedVariations = variations.filter(v => v.rotation === rotation);
      const frontPoints = rotatedVariations.find(v => v.partName === 'left_upper_arm_front' || v.partName === 'left_lower_arm_front')?.extremePoints;
      const backPoints = rotatedVariations.find(v => v.partName === 'left_upper_arm_back' || v.partName === 'left_lower_arm_back')?.extremePoints;

      if (frontPoints && backPoints) {
          rotationAverages[rotation] = {
              top: {
                  x: Math.round((frontPoints.top.x + backPoints.top.x) / 2),
                  y: Math.round((frontPoints.top.y + backPoints.top.y) / 2)
              },
              bottom: {
                  x: Math.round((frontPoints.bottom.x + backPoints.bottom.x) / 2),
                  y: Math.round((frontPoints.bottom.y + backPoints.bottom.y) / 2)
              }
          };
      }
  }

  // Send back processed data
  self.postMessage({
      variations: variations,
      partNames: partNames,
      measurements: measurements,
      rotationAverages: rotationAverages
  }, variations.map(v => v.data));
};

// Helper function to rotate an image segment
function rotateSegment(sourceData, width, height, center, angle) {
  const resultData = new Uint8ClampedArray(width * height * 4);
  const angleRad = (angle * Math.PI) / 180;
  const cos = Math.cos(angleRad);
  const sin = Math.sin(angleRad);

  for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
          const sourceIdx = (y * width + x) * 4;

          if (sourceData[sourceIdx + 3] > 0) {
              // Calculate position relative to rotation center
              const dx = x - center.x;
              const dy = y - center.y;

              // Rotate point
              const rotatedX = Math.round(center.x + (dx * cos - dy * sin));
              const rotatedY = Math.round(center.y + (dx * sin + dy * cos));

              if (rotatedX >= 0 && rotatedX < width &&
                  rotatedY >= 0 && rotatedY < height) {
                  const targetIdx = (rotatedY * width + rotatedX) * 4;
                  resultData[targetIdx] = sourceData[sourceIdx];
                  resultData[targetIdx + 1] = sourceData[sourceIdx + 1];
                  resultData[targetIdx + 2] = sourceData[sourceIdx + 2];
                  resultData[targetIdx + 3] = sourceData[sourceIdx + 3];
              }
          }
      }
  }

  return resultData;
}

// Helper function to rotate keypoints
function rotateKeypoints(points, center, angle) {
  const angleRad = (angle * Math.PI) / 180;
  const cos = Math.cos(angleRad);
  const sin = Math.sin(angleRad);

  function rotatePoint(point) {
      const dx = point.x - center.x;
      const dy = point.y - center.y;
      return {
          x: Math.round(center.x + (dx * cos - dy * sin)),
          y: Math.round(center.y + (dx * sin + dy * cos))
      };
  }

  return {
      top: rotatePoint(points.top),
      bottom: rotatePoint(points.bottom)
  };
}